import java.io.FileWriter;
import java.io.File;
import java.util.Scanner;

public class Task1 {


    public static int[] negativeBeforePositive(int[] array) {

        int negCount = 0, posCount = 0, zeroCount = 0;

        for (int i = 0; i < array.length; i++) {
            if (array[i] < 0) {
               negCount++;
            } else if (array[i] > 0) {
               posCount++;
            } else {
               zeroCount++;
            }//if
        }//for


        int[] rearrangedArray = new int[array.length];
        int negIndex = 0;
        int zeroIndex = negCount;
        int posIndex = negCount + zeroCount;

        
        for (int i = 0; i < array.length; i++) {
            if (array[i] < 0) {
                rearrangedArray[negIndex] = array[i];
                negIndex++;
            } else if (array[i] == 0) {
                rearrangedArray[zeroIndex] = array[i];
                zeroIndex++;
            } else {
                rearrangedArray[posIndex] = array[i];
                posIndex++;
            }//if
        }//for


        for (int i = 0;i < negCount - 1 ; i++ ) {
            for (int j = i+1; j < negCount ; j++ ) {
                if (rearrangedArray[i] > rearrangedArray[j]) {
                    int temp = rearrangedArray[i];
                    rearrangedArray[i] = rearrangedArray[j];
                    rearrangedArray[j] = temp;
                    
                }//inner-if
            }//inner-for
        }//outer-for

       
       return rearrangedArray;
    }//method

    public static void printArray(int[] array) throws Exception{
        FileWriter fw = new FileWriter("Task1Output.txt");

        for (int i = 0; i < array.length; i++) {

            fw.write(array[i] + " ");
            // System.out.print(array[i] + " ");
        }//for
        
        fw.close();
    }//printArray()

    public static void main(String[] args) throws Exception {

        File file = new File("Task1Input.txt");
        Scanner read = new Scanner(file);

        int size = 0;
        while (read.hasNextInt()) {
            read.nextInt();
            size++;
        }//while

        // System.out.println("size: " + size);

        int[] array = new int[size];

        //Now move the cursor back to the front:
        read.close();
        read = new Scanner(file);

        int i = 0;
        while(read.hasNextInt()){
            array[i] = read.nextInt();
            i++;
        }//while


        array = negativeBeforePositive(array);
        printArray(array);
    }//main

}//class