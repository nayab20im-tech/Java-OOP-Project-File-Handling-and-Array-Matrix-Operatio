import java.io.FileWriter;
import java.io.File;
import java.util.Scanner;

public class Task2 {

    public static int[][] transpose(int[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length;
        int[][] transpose = new int[cols][rows];
        
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                transpose[j][i] = matrix[i][j];
            }//inner-for
        }//outer-for
        
        return transpose;
    }//transpose()

    public static boolean isSymmetric(int[][] matrix) {
        int[][] transpose = transpose(matrix);
        
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[0].length; j++) {
                if (matrix[i][j] != transpose[i][j]) {
                    return false;
                }//if
            }//inner-for
        }//outer-for
        
        return true;
    }

    public static void main(String[] args) throws Exception{


        File file=new File("Task2Input.txt");
        Scanner input=new Scanner(file);
        FileWriter fw = new FileWriter("Task2Output.txt");

        int row= input.nextInt();
        System.out.println("Row : " + row);

        int column=input.nextInt();
        System.out.println("Column: " + column);

        int [][] array = new int[row][column];

        for (int i = 0; i < array.length ; ++i) {
            for (int j = 0; j < array[i].length ; ++j){
                array[i][j] = input.nextInt();
            }//inner-for
        }//outer-for

        boolean res = isSymmetric(array);

        if (res) {

            fw.write("The matrix is symmetric.");

        } else {

           fw.write("The matrix is not symmetric.");
       }//if
       fw.close();
   }//main
}//class
